# MIC_Hands_on_Arthur_Ramos_Leonardo_Castro
**Componentes**: [Leonardo Castro](https://github.com/thetwelvedev) e [Arthur Ramos](https://github.com/ArthurRamos26)

## Hands-on básico

- [x] Sprint 0
- [ ] Sprint 1

## Big Picture
![big picture](./big-picture.png)

## Organograma
![organograma](./Organograma.png)

## Repositório
**Link**: https://github.com/ArthurRamos26/MIC_Hands_on_Arthur_Ramos_Leonardo_Castro